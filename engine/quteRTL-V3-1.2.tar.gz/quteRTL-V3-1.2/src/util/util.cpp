#include "rnGen.h"
#include "myUsage.h"

//----------------------------------------------------------------------
//    Global variables in util
//----------------------------------------------------------------------

RandomNumGen  rnGen(0);  // use random seed = 0
MyUsage       myUsage;

